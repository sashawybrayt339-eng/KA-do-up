# Backrooms: No Exit 1 — Windows build

Keyboard + mouse version with 4K-capable rendering, packaged with Electron.

## Controls
- W/A/S/D or arrow keys: move
- Mouse: look (click the game to lock the cursor)
- Space: jump
- Left click or F: take photo
- E: interact
- Mouse wheel: zoom
- Esc or P: pause
- G: gallery
- F11: fullscreen

## Build locally (Windows)
    npm install
    npm run dist

The installer is created in `dist/`.

## Build on GitHub
Push to `main`. The workflow in `.github/workflows/build-windows.yml` builds the installer.
Download it from the run's **Artifacts** section in the Actions tab.
